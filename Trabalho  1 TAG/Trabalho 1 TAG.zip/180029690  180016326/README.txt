Universidade de Bras�lia - Instituto de Ci�ncias Exatas
Departamento de Ci�ncia da Computa��o
CIC 117901 - Teoria e Aplica��o de Grafos 
2019.2 - Turma A - Professor Dibio Leandro Borges

Autores: 
18/0029690 - Alexandre Mitsuru Kaihara
18/0016326 - Felipe Xavier Barbosa da Silva

Trabalho 1

-Diretiva de compila��o utilizada:
	g++ -std=c++11 -o main main.cpp readfiles.cpp grafos.cpps