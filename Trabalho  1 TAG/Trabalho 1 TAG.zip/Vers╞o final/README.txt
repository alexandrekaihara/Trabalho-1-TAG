Universidade de Brasilia - Instituto de Ciencias Exatas
Departamento de Ciencia da Computacao
CIC 117901 - Teoria e Aplicacao de Grafos 
2019.2 - Turma A - Professor Dibio Leandro Borges

Autores: 
18/0029690 - Alexandre Mitsuru Kaihara
18/0016326 - Felipe Xavier Barbosa da Silva

Trabalho 1

-Diretiva de compilacao utilizada:
	g++ -std=c++11 -o main main.cpp readfiles.cpp grafos.cpp